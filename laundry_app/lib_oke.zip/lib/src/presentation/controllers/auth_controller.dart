// // auth_controller.dart
// import 'package:flutter/material.dart';
// import 'package:get_storage/get_storage.dart';
// import 'package:laundry_app/src/features/auth/domain/entities/user.dart';
// import 'package:laundry_app/src/features/auth/domain/usecases/login_usecase.dart';
// import 'package:laundry_app/src/features/auth/domain/usecases/register_usecase.dart';
// import 'package:laundry_app/src/features/auth/domain/usecases/verify_otp_usecase.dart';
// import '../../features/auth/domain/repositories/auth_repository.dart';
//
// class AuthController extends ChangeNotifier {
//   final LoginUseCase loginUseCase;
//   final RegisterUseCase registerUseCase;
//   final VerifyOTPUseCase verifyOTPUseCase;
//   final ResendOTPUseCase resendOTPUseCase;
//   final AuthRepository authRepository;
//
//   final GetStorage _storage = GetStorage();
//   static const String _userKey = 'current_user';
//
//   User? _currentUser;
//   bool _isLoading = false;
//   String? _errorMessage;
//   String? _successMessage;
//   String? _currentOTP;
//
//   // Getters
//   User? get currentUser => _currentUser;
//   bool get isLoading => _isLoading;
//   String? get errorMessage => _errorMessage;
//   String? get successMessage => _successMessage;
//   String? get currentOTP => _currentOTP;
//
//   // Kiểm tra đã login chưa
//   bool get isLoggedIn => _currentUser != null;
//
//   AuthController({
//     required this.loginUseCase,
//     required this.registerUseCase,
//     required this.verifyOTPUseCase,
//     required this.resendOTPUseCase,
//     required this.authRepository,
//   });
//
//   // ========== PUBLIC METHODS ==========
//
//   // Setter để cho phép set user từ bên ngoài
//   void setCurrentUser(User user) {
//     _currentUser = user;
//     _saveUserToStorage(user);
//     notifyListeners();
//   }
//   //
//   // // Method restore session từ cookies
//   // Future<void> restoreSession() async {
//   //   try {
//   //     print('🔄 Đang khôi phục session từ cookies...');
//   //     final user = await authRepository.getProfile();
//   //     _currentUser = user;
//   //     await _saveUserToStorage(user);
//   //     print('✅ Session restored: ${user.email}');
//   //     notifyListeners();
//   //   } catch (e) {
//   //     print('❌ Không có session: $e');
//   //     // Thử load từ storage nếu cookies không hoạt động
//   //     await _loadUserFromStorage();
//   //   }
//   // }
//   // Thêm method này để kiểm tra token
//   bool get hasValidToken => currentUser?.token != null && currentUser!.token!.isNotEmpty;
//
// // Sửa restoreSession
//   Future<void> restoreSession() async {
//     try {
//       print('🔄 Đang khôi phục session từ cookies...');
//
//       // Kiểm tra token trước khi gọi API
//       if (currentUser?.token == null) {
//         print('❌ Không có token, loading từ storage');
//         await _loadUserFromStorage();
//         return;
//       }
//
//       final user = await authRepository.getProfile();
//       _currentUser = user;
//       await _saveUserToStorage(user);
//       print('✅ Session restored: ${user.email}');
//       notifyListeners();
//     } catch (e) {
//       print('❌ Không có session: $e');
//       await _loadUserFromStorage();
//
//       // Nếu vẫn không có user, clear data
//       if (_currentUser == null) {
//         await _clearUserData();
//       }
//     }
//   }
//
//   // Load user từ storage khi app start
//   Future<void> loadUserFromStorage() async {
//     await _loadUserFromStorage();
//   }
//
//   void clearMessages() {
//     _errorMessage = null;
//     _successMessage = null;
//     notifyListeners();
//   }
//
//   // Login
//   // Future<bool> login(String email, String password) async {
//   //   _setLoading(true);
//   //   _clearMessages();
//   //
//   //   try {
//   //     final response = await loginUseCase.call(email, password);
//   //
//   //     if (response.success) {
//   //       User? loggedInUser;
//   //
//   //       // Lấy thông tin user từ profile API
//   //       try {
//   //         loggedInUser = await authRepository.getProfile();
//   //       } catch (e) {
//   //         print('Error getting profile: $e');
//   //         loggedInUser = User(
//   //           id: null,
//   //           fullName: email.split('@').first,
//   //           email: email,
//   //           phone: '',
//   //         );
//   //       }
//   //
//   //       _currentUser = loggedInUser;
//   //       await _saveUserToStorage(loggedInUser);
//   //
//   //       _setSuccess(response.message);
//   //       return true;
//   //     } else {
//   //       _setError(response.message);
//   //       return false;
//   //     }
//   //   } catch (e) {
//   //     _setError(e.toString().replaceAll('Exception: ', ''));
//   //     return false;
//   //   } finally {
//   //     _setLoading(false);
//   //   }
//   // }
//
//   // Future<bool> login(String email, String password) async {
//   //   _setLoading(true);
//   //   _clearMessages();
//   //
//   //   try {
//   //     final response = await loginUseCase.call(email, password);
//   //
//   //     if (response.success) {
//   //       User? loggedInUser;
//   //
//   //       // Tạo user với token từ response
//   //       if (response.user != null) {
//   //         loggedInUser = response.user!;
//   //       } else {
//   //         // Nếu response không có user, thử lấy từ profile API
//   //         try {
//   //           loggedInUser = await authRepository.getProfile();
//   //         } catch (e) {
//   //           print('Error getting profile: $e');
//   //           loggedInUser = User(
//   //             id: response.user?.id ?? null,
//   //             fullName: email.split('@').first,
//   //             email: email,
//   //             phone: '',
//   //             token: response.user?.token, // ⬅️ Lưu token nếu có
//   //           );
//   //         }
//   //       }
//   //
//   //       // ⬇️ QUAN TRỌNG: Gán token từ response nếu chưa có
//   //       if (loggedInUser.token == null && response.user?.token != null) {
//   //         loggedInUser = User(
//   //           id: loggedInUser.id,
//   //           fullName: loggedInUser.fullName,
//   //           email: loggedInUser.email,
//   //           phone: loggedInUser.phone,
//   //           image: loggedInUser.image,
//   //           token: response.user!.token, // ⬅️ Lấy token từ response
//   //         );
//   //       }
//   //
//   //       _currentUser = loggedInUser;
//   //       await _saveUserToStorage(loggedInUser);
//   //
//   //       print('✅ Login successful, token saved: ${loggedInUser.token != null}');
//   //       _setSuccess(response.message);
//   //       return true;
//   //     } else {
//   //       _setError(response.message);
//   //       return false;
//   //     }
//   //   } catch (e) {
//   //     _setError(e.toString().replaceAll('Exception: ', ''));
//   //     return false;
//   //   } finally {
//   //     _setLoading(false);
//   //   }
//   // }
// // ✅ FIXED LOGIN METHOD - Đảm bảo lưu token
//   Future<bool> login(String email, String password) async {
//     _setLoading(true);
//     _clearMessages();
//
//     try {
//       final response = await loginUseCase.call(email, password);
//
//       if (response.success && response.user != null) {
//         final loggedInUser = response.user!;
//
//         // ✅ DEBUG: Kiểm tra token có được parse không
//         print('🔐 Login Response:');
//         print('  - User ID: ${loggedInUser.id}');
//         print('  - Email: ${loggedInUser.email}');
//         print('  - Token: ${loggedInUser.token}');
//         print('  - Has Token: ${loggedInUser.token != null && loggedInUser.token!.isNotEmpty}');
//
//         // ✅ QUAN TRỌNG: Lưu user VÀ token vào storage
//         _currentUser = loggedInUser;
//         await _saveUserToStorage(loggedInUser);
//
//         // ✅ Verify token đã được lưu
//         final savedUserJson = _storage.read<Map<String, dynamic>>(_userKey);
//         print('💾 Saved to storage:');
//         print('  - Token in storage: ${savedUserJson?['token']}');
//
//         _setSuccess(response.message);
//         return true;
//       } else {
//         _setError(response.message);
//         return false;
//       }
//     } catch (e) {
//       print('❌ Login error: $e');
//       _setError(e.toString().replaceAll('Exception: ', ''));
//       return false;
//     } finally {
//       _setLoading(false);
//     }
//   }
//
//   // ✅ FIXED SAVE TO STORAGE - Đảm bảo lưu token
//   Future<void> _saveUserToStorage(User user) async {
//     final userJson = {
//       'id': user.id,
//       'fullName': user.fullName,
//       'email': user.email,
//       'phone': user.phone,
//       'image': user.image,
//       'token': user.token, // ✅ Lưu token
//     };
//
//     await _storage.write(_userKey, userJson);
//
//     print('💾 User saved to storage:');
//     print('  - Email: ${user.email}');
//     print('  - Token saved: ${user.token != null}');
//     print('  - Token length: ${user.token?.length ?? 0}');
//   }
//
//   // ✅ FIXED LOAD FROM STORAGE
//   Future<void> _loadUserFromStorage() async {
//     print('🔄 Loading user from storage...');
//     final userJson = _storage.read<Map<String, dynamic>>(_userKey);
//
//     if (userJson != null) {
//       print('📦 User JSON from storage: $userJson');
//
//       _currentUser = User(
//         id: userJson['id'],
//         fullName: userJson['fullName'],
//         email: userJson['email'],
//         phone: userJson['phone'],
//         image: userJson['image'],
//         token: userJson['token'], // ✅ Load token
//       );
//
//       print('📱 User loaded from storage:');
//       print('  - Email: ${_currentUser?.email}');
//       print('  - Token exists: ${_currentUser?.token != null}');
//       print('  - Token length: ${_currentUser?.token?.length ?? 0}');
//
//       notifyListeners();
//     } else {
//       print('📱 No user found in storage');
//     }
//   }
//   // Register
//   Future<bool> register({
//     required String fullName,
//     required String email,
//     required String phone,
//     required String password,
//   }) async {
//     _setLoading(true);
//     _clearMessages();
//
//     try {
//       final response = await registerUseCase.call(
//         fullName: fullName,
//         email: email,
//         phone: phone,
//         password: password,
//       );
//
//       if (response.success) {
//         _currentOTP = response.otp;
//         _setSuccess(response.message);
//         return true;
//       } else {
//         _setError(response.message);
//         return false;
//       }
//     } catch (e) {
//       _setError(e.toString().replaceAll('Exception: ', ''));
//       return false;
//     } finally {
//       _setLoading(false);
//     }
//   }
//
//   // Verify OTP
//   Future<bool> verifyOTP(String otp) async {
//     _setLoading(true);
//     _clearMessages();
//
//     try {
//       final response = await verifyOTPUseCase.call(otp);
//
//       if (response.success) {
//         _setSuccess(response.message);
//         return true;
//       } else {
//         _setError(response.message);
//         return false;
//       }
//     } catch (e) {
//       _setError(e.toString().replaceAll('Exception: ', ''));
//       return false;
//     } finally {
//       _setLoading(false);
//     }
//   }
//
//   // Resend OTP
//   Future<bool> resendOTP(String email) async {
//     _clearMessages();
//
//     try {
//       final success = await resendOTPUseCase.call(email);
//
//       if (success) {
//         _setSuccess('Đã gửi lại mã OTP');
//         return true;
//       } else {
//         _setError('Gửi lại OTP thất bại');
//         return false;
//       }
//     } catch (e) {
//       _setError(e.toString().replaceAll('Exception: ', ''));
//       return false;
//     }
//   }
//
//   // Logout
//   Future<void> logout() async {
//     try {
//       await authRepository.logout();
//     } catch (e) {
//       print('Error calling logout API: $e');
//     }
//
//     // Luôn clear dữ liệu local dù API có thành công hay không
//     await _clearUserData();
//   }
//
//   // Fetch profile
//   Future<void> fetchProfile() async {
//     try {
//       final user = await authRepository.getProfile();
//       _currentUser = user;
//       await _saveUserToStorage(user);
//       notifyListeners();
//     } catch (e) {
//       print('Error fetching profile: $e');
//     }
//   }
//
//   // ========== PRIVATE METHODS ==========
//
//   void _setLoading(bool value) {
//     _isLoading = value;
//     notifyListeners();
//   }
//
//   void _setError(String? message) {
//     _errorMessage = message;
//     notifyListeners();
//   }
//
//   void _setSuccess(String? message) {
//     _successMessage = message;
//     notifyListeners();
//   }
//
//   void _clearMessages() {
//     _errorMessage = null;
//     _successMessage = null;
//   }
//
//   // // Lưu user vào storage
//   // Future<void> _saveUserToStorage(User user) async {
//   //   final userJson = {
//   //     'id': user.id,
//   //     'fullName': user.fullName,
//   //     'email': user.email,
//   //     'phone': user.phone,
//   //     'image': user.image,
//   //     'token': user.token,
//   //   };
//   //   await _storage.write(_userKey, userJson);
//   //   print('💾 User saved to storage: ${user.email}');
//   // }
//   //
//   // // Load user từ storage
//   // // Future<void> _loadUserFromStorage() async {
//   // //   final userJson = _storage.read<Map<String, dynamic>>(_userKey);
//   // //   if (userJson != null) {
//   // //     _currentUser = User(
//   // //       id: userJson['id'],
//   // //       fullName: userJson['fullName'],
//   // //       email: userJson['email'],
//   // //       phone: userJson['phone'],
//   // //       image: userJson['image'],
//   // //       token: userJson['token'],
//   // //     );
//   // //     print('📱 User loaded from storage: ${_currentUser?.email}');
//   // //     notifyListeners();
//   // //   }
//   // // }
//   // Future<void> _loadUserFromStorage() async {
//   //   print('🔄 Loading user from storage...');
//   //   final userJson = _storage.read<Map<String, dynamic>>(_userKey);
//   //   if (userJson != null) {
//   //     print('📦 User JSON from storage: $userJson');
//   //     _currentUser = User(
//   //       id: userJson['id'],
//   //       fullName: userJson['fullName'],
//   //       email: userJson['email'],
//   //       phone: userJson['phone'],
//   //       image: userJson['image'],
//   //       token: userJson['token'], // ĐẢM BẢO TOKEN ĐƯỢC LƯU
//   //     );
//   //     print('📱 User loaded from storage: ${_currentUser?.email}');
//   //     print('🔑 Token exists: ${_currentUser?.token != null}');
//   //     notifyListeners();
//   //   } else {
//   //     print('📱 No user found in storage');
//   //   }
//   // }
//
//   // Xóa tất cả user data
//   Future<void> _clearUserData() async {
//     await _storage.remove(_userKey);
//     _currentUser = null;
//     _currentOTP = null;
//     _errorMessage = null;
//     _successMessage = null;
//     print('🗑️ All user data cleared');
//     notifyListeners();
//   }
// }
// auth_controller.dart
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:laundry_app/src/features/auth/domain/entities/user.dart';
import 'package:laundry_app/src/features/auth/domain/usecases/login_usecase.dart';
import 'package:laundry_app/src/features/auth/domain/usecases/register_usecase.dart';
import 'package:laundry_app/src/features/auth/domain/usecases/verify_otp_usecase.dart';
import '../../features/auth/domain/repositories/auth_repository.dart';

class AuthController extends ChangeNotifier {
  final LoginUseCase loginUseCase;
  final RegisterUseCase registerUseCase;
  final VerifyOTPUseCase verifyOTPUseCase;
  final ResendOTPUseCase resendOTPUseCase;
  final AuthRepository authRepository;

  final GetStorage _storage = GetStorage();
  static const String _userKey = 'current_user';

  User? _currentUser;
  bool _isLoading = false;
  String? _errorMessage;
  String? _successMessage;
  String? _currentOTP;

  // Getters
  User? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String? get successMessage => _successMessage;
  String? get currentOTP => _currentOTP;
  bool get isLoggedIn => _currentUser != null && hasValidToken;
  bool get hasValidToken => currentUser?.token != null && currentUser!.token!.isNotEmpty;

  AuthController({
    required this.loginUseCase,
    required this.registerUseCase,
    required this.verifyOTPUseCase,
    required this.resendOTPUseCase,
    required this.authRepository,
  });

  // ========== PUBLIC METHODS ==========

  void setCurrentUser(User user) {
    _currentUser = user;
    _saveUserToStorage(user);
    notifyListeners();
  }

  Future<void> restoreSession() async {
    try {
      print('🔄 Đang khôi phục session...');

      // Kiểm tra token trước khi gọi API
      if (!hasValidToken) {
        print('❌ Không có token hợp lệ');
        await _loadUserFromStorage();
        return;
      }

      print('✅ Đã có token, đang verify với server...');

      // Thử lấy profile từ server để verify token
      try {
        final user = await authRepository.getProfile();

        // Giữ lại token cũ vì API getProfile không trả token
        _currentUser = User(
          id: user.id,
          fullName: user.fullName,
          email: user.email,
          phone: user.phone,
          image: user.image,
          token: _currentUser?.token, // ✅ Giữ lại token cũ
        );

        await _saveUserToStorage(_currentUser!);
        print('✅ Session restored: ${user.email}');
        notifyListeners();
      } catch (e) {
        print('⚠️ Token không hợp lệ hoặc hết hạn: $e');
        // Token không còn hợp lệ, clear data
        await _clearUserData();
      }
    } catch (e) {
      print('❌ Không thể restore session: $e');
      await _loadUserFromStorage();
    }
  }

  Future<void> loadUserFromStorage() async {
    await _loadUserFromStorage();
  }

  void clearMessages() {
    _errorMessage = null;
    _successMessage = null;
    notifyListeners();
  }

  // ✅ FIXED LOGIN - Lưu token đúng cách
  Future<bool> login(String email, String password) async {
    _setLoading(true);
    _clearMessages();

    try {
      final response = await loginUseCase.call(email, password);

      if (response.success && response.user != null) {
        final loggedInUser = response.user!;

        // ✅ DEBUG: Kiểm tra token
        print('🔐 Login Response:');
        print('  - User ID: ${loggedInUser.id}');
        print('  - Email: ${loggedInUser.email}');
        print('  - Token exists: ${loggedInUser.token != null}');
        print('  - Token length: ${loggedInUser.token?.length ?? 0}');

        // ✅ Lưu user VÀ token
        _currentUser = loggedInUser;
        await _saveUserToStorage(loggedInUser);

        // ✅ Verify đã lưu
        final savedUserJson = _storage.read<Map<String, dynamic>>(_userKey);
        print('💾 Token in storage: ${savedUserJson?['token'] != null ? "✓" : "✗"}');

        _setSuccess(response.message);
        return true;
      } else {
        _setError(response.message);
        return false;
      }
    } catch (e) {
      print('❌ Login error: $e');
      _setError(e.toString().replaceAll('Exception: ', ''));
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Register
  Future<bool> register({
    required String fullName,
    required String email,
    required String phone,
    required String password,
  }) async {
    _setLoading(true);
    _clearMessages();

    try {
      final response = await registerUseCase.call(
        fullName: fullName,
        email: email,
        phone: phone,
        password: password,
      );

      if (response.success) {
        _currentOTP = response.otp;
        _setSuccess(response.message);
        return true;
      } else {
        _setError(response.message);
        return false;
      }
    } catch (e) {
      _setError(e.toString().replaceAll('Exception: ', ''));
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Verify OTP
  Future<bool> verifyOTP(String otp) async {
    _setLoading(true);
    _clearMessages();

    try {
      final response = await verifyOTPUseCase.call(otp);

      if (response.success) {
        _setSuccess(response.message);
        return true;
      } else {
        _setError(response.message);
        return false;
      }
    } catch (e) {
      _setError(e.toString().replaceAll('Exception: ', ''));
      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Resend OTP
  Future<bool> resendOTP(String email) async {
    _clearMessages();

    try {
      final success = await resendOTPUseCase.call(email);

      if (success) {
        _setSuccess('Đã gửi lại mã OTP');
        return true;
      } else {
        _setError('Gửi lại OTP thất bại');
        return false;
      }
    } catch (e) {
      _setError(e.toString().replaceAll('Exception: ', ''));
      return false;
    }
  }

  // Logout
  Future<void> logout() async {
    try {
      await authRepository.logout();
    } catch (e) {
      print('Error calling logout API: $e');
    }

    // Luôn clear dữ liệu local dù API có thành công hay không
    await _clearUserData();
  }

  // Fetch profile
  Future<void> fetchProfile() async {
    try {
      final user = await authRepository.getProfile();

      // Giữ lại token cũ
      _currentUser = User(
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
        image: user.image,
        token: _currentUser?.token,
      );

      await _saveUserToStorage(_currentUser!);
      notifyListeners();
    } catch (e) {
      print('Error fetching profile: $e');
    }
  }

  // ========== PRIVATE METHODS ==========

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setError(String? message) {
    _errorMessage = message;
    notifyListeners();
  }

  void _setSuccess(String? message) {
    _successMessage = message;
    notifyListeners();
  }

  void _clearMessages() {
    _errorMessage = null;
    _successMessage = null;
  }

  // ✅ FIXED: Lưu user vào storage với token
  Future<void> _saveUserToStorage(User user) async {
    final userJson = {
      'id': user.id,
      'fullName': user.fullName,
      'email': user.email,
      'phone': user.phone,
      'image': user.image,
      'token': user.token, // ✅ Lưu token
    };

    await _storage.write(_userKey, userJson);

    print('💾 User saved to storage:');
    print('  - Email: ${user.email}');
    print('  - Token saved: ${user.token != null}');
  }

  // ✅ FIXED: Load user từ storage với token
  Future<void> _loadUserFromStorage() async {
    print('🔄 Loading user from storage...');
    final userJson = _storage.read<Map<String, dynamic>>(_userKey);

    if (userJson != null) {
      print('📦 User JSON from storage found');

      _currentUser = User(
        id: userJson['id'],
        fullName: userJson['fullName'],
        email: userJson['email'],
        phone: userJson['phone'],
        image: userJson['image'],
        token: userJson['token'], // ✅ Load token
      );

      print('📱 User loaded:');
      print('  - Email: ${_currentUser?.email}');
      print('  - Has Token: ${_currentUser?.token != null}');

      notifyListeners();
    } else {
      print('📱 No user found in storage');
    }
  }

  // Xóa tất cả user data
  Future<void> _clearUserData() async {
    await _storage.remove(_userKey);
    _currentUser = null;
    _currentOTP = null;
    _errorMessage = null;
    _successMessage = null;
    print('🗑️ All user data cleared');
    notifyListeners();
  }
}
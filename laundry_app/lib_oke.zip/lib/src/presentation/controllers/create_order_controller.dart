 class MyWashingPackageModel{
    String ? name;
    double ? discount;
    DateTime ? expirationDate;

    MyWashingPackageModel({
      this.name,
      this.discount,
      this.expirationDate
    });


}
// // import 'package:cookie_jar/cookie_jar.dart';
// // import 'package:flutter/material.dart';
// // import 'package:get/get_core/src/get_main.dart';
// // import 'package:get/get_instance/src/extension_instance.dart';
// // import 'package:get/get_navigation/src/root/get_material_app.dart';
// // import 'package:http/http.dart' as http;
// // import 'package:laundry_app/src/core/di/auth_dependency_injection.dart';
// // import 'package:laundry_app/src/core/di/rating_injection.dart';
// // import 'package:laundry_app/src/core/theme/app_theme.dart';
// // import 'package:laundry_app/src/presentation/controllers/home_controller.dart';
// // import 'package:laundry_app/src/presentation/layouts/layout_menu.dart';
// // import 'package:laundry_app/src/router/app_routes.dart';
// // import 'package:provider/provider.dart';
// //
// // import 'core/di/laundry_injection.dart';
// // import 'core/di/order_injection.dart';
// // import 'core/di/service_injection.dart';
// // import 'core/di/tracking_injection.dart';
// // import 'core/di/voucher_injection.dart';
// // import 'core/services/api_client.dart';
// // import 'core/services/auth_service.dart';
// // import 'features/home/data/datasources/home_remote_datasource.dart';
// // import 'features/home/data/repositories/home_repository_impl.dart';
// // import 'features/home/domain/repositories/home_repository.dart';
// //
// //
// // class LaundryApp extends StatelessWidget {
// //   const LaundryApp({super.key});
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     // // Initialize dependencies
// //     // _initDependencies();
// //     return MultiProvider(
// //       providers: [
// //         ChangeNotifierProvider(create: (_) => AuthDI.getAuthController(),),
// //         ChangeNotifierProvider(create: (_) => ServiceDI.getServiceController(),),
// //         ChangeNotifierProvider(create: (_) => VoucherInjection.createVoucherControllerWithMock(),),
// //         // ChangeNotifierProvider(create: (_) => VoucherInjection.createVoucherControllerWithAPI('https://your-api-url.com',),),
// //         ChangeNotifierProvider(create: (_) => RatingInjection.createRatingController(useMockData: true,apiBaseUrl: 'https://api.example.com',),),
// //         ChangeNotifierProvider(create: (_) => TrackingInjection.createTrackingControllerWithMock(),),
// //         // ChangeNotifierProvider(create: (_) => TrackingInjection.createTrackingControllerWithAPI('https://your-api-url.com',),),
// //         ChangeNotifierProvider(create: (_) => OrderInjection.createOrderControllerWithMock(),),
// //         // ChangeNotifierProvider(create: (_) => OrderInjection.createOrderControllerWithAPI('https://your-api-url.com',),),
// //         // ChangeNotifierProvider(create: (_) =>  LaundryDI.getProvider(),),
// //
// //       ],
// //       child: MaterialApp(
// //         title: 'Laundry',
// //         theme: AppTheme.lightTheme,
// //         debugShowCheckedModeBanner: false,
// //         // initialRoute: AppRoutes.auth,
// //         initialRoute: AppRoutes.login,
// //         routes: AppRoutes.routes,
// //       ),
// //     );
// //   }
// //
// //   //
// //   // void _initDependencies() {
// //   //   // 1. Register CookieJar (nếu chưa có)
// //   //   Get.put(CookieJar(), permanent: true);
// //   //
// //   //   // 2. Register ApiClient với CookieJar
// //   //   Get.put(
// //   //     ApiClient(
// //   //       client: http.Client(),
// //   //       cookieJar: Get.find<CookieJar>(), // Inject CookieJar
// //   //     ),
// //   //     permanent: true,
// //   //   );
// //   //
// //   //   // 3. Register DataSource
// //   //   Get.lazyPut<HomeRemoteDataSource>(
// //   //         () => HomeRemoteDataSourceImpl(apiClient: Get.find()),
// //   //   );
// //   //
// //   //   // 4. Register Repository
// //   //   Get.lazyPut<HomeRepository>(
// //   //         () => HomeRepositoryImpl(remoteDataSource: Get.find()),
// //   //   );
// //   //
// //   //   // 5. Register Controller
// //   //   Get.lazyPut(() => HomeController(repository: Get.find()));
// //   // }
// // }
// import 'package:flutter/material.dart';
// import 'package:laundry_app/src/core/di/auth_dependency_injection.dart';
// import 'package:laundry_app/src/core/di/rating_injection.dart';
// import 'package:laundry_app/src/core/di/order_injection.dart';
// import 'package:laundry_app/src/core/di/service_injection.dart';
// import 'package:laundry_app/src/core/di/tracking_injection.dart';
// import 'package:laundry_app/src/core/di/voucher_injection.dart';
// import 'package:laundry_app/src/core/theme/app_theme.dart';
// import 'package:laundry_app/src/presentation/controllers/auth_controller.dart';
// import 'package:laundry_app/src/presentation/layouts/layout_menu.dart';
// import 'package:laundry_app/src/router/app_routes.dart';
// import 'package:provider/provider.dart';
//
// import 'core/di/home_dependency_injection.dart';
//
// class LaundryApp extends StatelessWidget {
//   const LaundryApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return MultiProvider(
//       providers: [
//         ChangeNotifierProvider(
//           create: (_) => AuthDI.getAuthController(),
//         ),
//         ChangeNotifierProvider(
//           create: (_) => HomeDI.getHomeController(),
//         ),
//         ChangeNotifierProvider(
//           create: (_) => ServiceDI.getServiceController(),
//         ),
//         ChangeNotifierProvider(
//           create: (_) => VoucherInjection.createVoucherControllerWithMock(),
//         ),
//         ChangeNotifierProvider(
//           create: (_) => RatingInjection.createRatingController(
//             useMockData: true,
//             apiBaseUrl: 'https://api.example.com',
//           ),
//         ),
//         ChangeNotifierProvider(
//           create: (_) => TrackingInjection.createTrackingControllerWithMock(),
//         ),
//         ChangeNotifierProvider(
//           create: (_) => OrderInjection.createOrderControllerWithMock(),
//         ),
//       ],
//       child: Builder(
//         builder: (context) {
//           final authController = context.watch<AuthController>();
//
//           return MaterialApp(
//             title: 'Laundry',
//             theme: AppTheme.lightTheme,
//             debugShowCheckedModeBanner: false,
//
//             // Điều hướng thông minh dựa trên login status
//             home: _buildHomeScreen(context, authController),
//
//             routes: AppRoutes.routes,
//           );
//         },
//       ),
//     );
//   }
//
//   // THÊM THAM SỐ BuildContext context
//   Widget _buildHomeScreen(BuildContext context, AuthController authController) {
//     // Nếu đang loading
//     if (authController.isLoading && authController.currentUser == null) {
//       return Scaffold(
//         body: Center(
//           child: CircularProgressIndicator(),
//         ),
//       );
//     }
//
//     // Nếu đã login
//     if (authController.isLoggedIn) {
//       return AppScreenWithBottomNavBar();
//     }
//
//     // Nếu chưa login
//     return AppRoutes.routes[AppRoutes.login]?.call(context) ??
//         Scaffold(
//           body: Center(
//             child: Text('Login screen not found'),
//           ),
//         );
//   }
// }
// app.dart
import 'package:flutter/material.dart';
import 'package:laundry_app/src/core/di/auth_dependency_injection.dart';
import 'package:laundry_app/src/core/di/home_dependency_injection.dart'; // Thêm import
import 'package:laundry_app/src/core/di/rating_injection.dart';
import 'package:laundry_app/src/core/di/order_injection.dart';
import 'package:laundry_app/src/core/di/service_injection.dart';
import 'package:laundry_app/src/core/di/tracking_injection.dart';
import 'package:laundry_app/src/core/di/voucher_injection.dart';
import 'package:laundry_app/src/core/theme/app_theme.dart';
import 'package:laundry_app/src/presentation/controllers/auth_controller.dart';
import 'package:laundry_app/src/presentation/layouts/layout_menu.dart';
import 'package:laundry_app/src/router/app_routes.dart';
import 'package:provider/provider.dart';

class LaundryApp extends StatelessWidget {
  const LaundryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => AuthDI.getAuthController(),
        ),
        // Thay ServiceDI bằng HomeDI
        ChangeNotifierProvider(
          create: (_) => HomeDI.getHomeController(),
        ),
        ChangeNotifierProvider(
          create: (_) => ServiceDI.getServiceController(),
        ),
        ChangeNotifierProvider(
          create: (_) => VoucherInjection.createVoucherControllerWithMock(),
        ),
        ChangeNotifierProvider(
          create: (_) => RatingInjection.createRatingController(
            useMockData: true,
            apiBaseUrl: 'https://api.example.com',
          ),
        ),
        ChangeNotifierProvider(
          create: (_) => TrackingInjection.createTrackingControllerWithMock(),
        ),
        ChangeNotifierProvider(
          create: (_) => OrderInjection.createOrderControllerWithMock(),
        ),
      ],
      child: Consumer<AuthController>(
        builder: (context, authController, child) {
          return MaterialApp(
            title: 'Laundry',
            theme: AppTheme.lightTheme,
            debugShowCheckedModeBanner: false,

            home: _buildHomeBasedOnAuth(context, authController),

            routes: AppRoutes.routes,
          );
        },
      ),
    );
  }

  Widget _buildHomeBasedOnAuth(BuildContext context, AuthController authController) {
    // Nếu đang loading
    if (authController.isLoading && authController.currentUser == null) {
      return Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    // Nếu đã login
    if (authController.isLoggedIn) {
      return AppScreenWithBottomNavBar();
    }

    // Nếu chưa login
    return Builder(
      builder: (context) {
        final routeBuilder = AppRoutes.routes[AppRoutes.login];
        if (routeBuilder != null) {
          return routeBuilder(context);
        }
        return Scaffold(
          body: Center(
            child: Text('Login screen not found'),
          ),
        );
      },
    );
  }
}
class WashingPackageModel{
  String ? name;
  String ? description;
  String ? note;
  double ? price;

  WashingPackageModel({
    this.name,
    this.description,
    this.note,
    this.price
  });
}
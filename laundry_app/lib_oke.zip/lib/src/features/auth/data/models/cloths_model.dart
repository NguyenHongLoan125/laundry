class ClothsModel{
  String ? name;
  String ? iconUrl;

  ClothsModel({this.name, this.iconUrl});
}
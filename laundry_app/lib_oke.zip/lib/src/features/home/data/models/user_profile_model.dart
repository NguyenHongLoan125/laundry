import '../../domain/entities/user_profile.dart';

class UserProfileModel extends UserProfile {
  UserProfileModel({
    required super.id,
    required super.name,
    super.email,
    super.phone,
  });

  factory UserProfileModel.fromJson(Map<String, dynamic> json) {
    print('📋 Profile JSON: $json'); // ADD THIS

    return UserProfileModel(
      id: json['_id'] ?? json['id'] ?? '',
      name: json['name'] ?? json['fullName'] ?? '',
      email: json['email'],
      phone: json['phone'] ?? json['phoneNumber'],
    );
  }
}
   
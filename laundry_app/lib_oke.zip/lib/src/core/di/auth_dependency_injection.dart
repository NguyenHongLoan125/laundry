// // auth_dependency_injection.dart
// import 'package:dio/dio.dart';
// import 'package:cookie_jar/cookie_jar.dart';
// import 'package:dio_cookie_manager/dio_cookie_manager.dart';
// import 'package:flutter/material.dart';
// import 'package:get_storage/get_storage.dart';
// import 'package:laundry_app/src/core/config/app_config.dart';
// import 'package:laundry_app/src/features/auth/data/datasources/auth_remote_data_source.dart';
// import 'package:laundry_app/src/features/auth/data/repositories/auth_repository_impl.dart';
// import 'package:laundry_app/src/features/auth/domain/repositories/auth_repository.dart';
// import 'package:laundry_app/src/features/auth/domain/usecases/login_usecase.dart';
// import 'package:laundry_app/src/features/auth/domain/usecases/register_usecase.dart';
// import 'package:laundry_app/src/features/auth/domain/usecases/verify_otp_usecase.dart';
// import 'package:laundry_app/src/presentation/controllers/auth_controller.dart';
//
// class AuthDI {
//   // CookieJar để lưu cookies
//   static final CookieJar _cookieJar = CookieJar();
//
//   // Dio Instance với CookieManager
//   static final Dio _dio = Dio(
//     BaseOptions(
//       baseUrl: AppConfig.baseUrl,
//       connectTimeout: const Duration(seconds: 30),
//       receiveTimeout: const Duration(seconds: 30),
//       headers: {
//         'Content-Type': 'application/json',
//         'Accept': 'application/json',
//       },
//     ),
//   )..interceptors.addAll([
//     CookieManager(_cookieJar), // Thêm CookieManager
//     LogInterceptor(
//       requestBody: true,
//       responseBody: true,
//       requestHeader: true,
//       responseHeader: true,
//       logPrint: (obj) => print('[Auth API] $obj'),
//     ),
//   ]);
//
//   // SINGLETON AuthController instance
//   static AuthController? _authControllerInstance;
//
//   // Initialize flag
//   static bool _initialized = false;
//
//   // Initialize tất cả dependencies và khôi phục session
//   // static Future<void> init({String? customBaseUrl}) async {
//   //   if (_initialized) return;
//   //
//   //   // Khởi tạo GetStorage
//   //   await GetStorage.init();
//   //
//   //   // Nếu có custom base URL, set environment
//   //   if (customBaseUrl != null) {
//   //     EnvironmentConfig.setEnvironment(EnvironmentConfig.development);
//   //   }
//   //
//   //   // Khởi tạo Data Source
//   //   final _remoteDataSource = AuthRemoteDataSourceImpl(dio: _dio);
//   //
//   //   // Khởi tạo Repository
//   //   final _repository = AuthRepositoryImpl(remoteDataSource: _remoteDataSource);
//   //
//   //   // Khởi tạo Use Cases
//   //   final _loginUseCase = LoginUseCase(_repository);
//   //   final _registerUseCase = RegisterUseCase(_repository);
//   //   final _verifyOTPUseCase = VerifyOTPUseCase(_repository);
//   //   final _resendOTPUseCase = ResendOTPUseCase(_repository);
//   //
//   //   // Khởi tạo AuthController SINGLETON
//   //   _authControllerInstance = AuthController(
//   //     loginUseCase: _loginUseCase,
//   //     registerUseCase: _registerUseCase,
//   //     verifyOTPUseCase: _verifyOTPUseCase,
//   //     resendOTPUseCase: _resendOTPUseCase,
//   //     authRepository: _repository,
//   //   );
//   //
//   //   // Load user từ storage trước
//   //   await _authControllerInstance?.loadUserFromStorage();
//   //
//   //   // Thử restore session từ cookies (async)
//   //   WidgetsBinding.instance.addPostFrameCallback((_) async {
//   //     await restoreUserSession();
//   //   });
//   //
//   //   _initialized = true;
//   // }
//
//   static Future<void> init({String? customBaseUrl}) async {
//     if (_initialized) return;
//
//     // Khởi tạo GetStorage
//     await GetStorage.init();
//
//     // Nếu có custom base URL, set environment
//     if (customBaseUrl != null) {
//       EnvironmentConfig.setEnvironment(EnvironmentConfig.development);
//     }
//
//     // Khởi tạo Data Source
//     final _remoteDataSource = AuthRemoteDataSourceImpl(dio: _dio);
//
//     // Khởi tạo Repository
//     final _repository = AuthRepositoryImpl(remoteDataSource: _remoteDataSource);
//
//     // Khởi tạo Use Cases
//     final _loginUseCase = LoginUseCase(_repository);
//     final _registerUseCase = RegisterUseCase(_repository);
//     final _verifyOTPUseCase = VerifyOTPUseCase(_repository);
//     final _resendOTPUseCase = ResendOTPUseCase(_repository);
//
//     // Khởi tạo AuthController SINGLETON
//     _authControllerInstance = AuthController(
//       loginUseCase: _loginUseCase,
//       registerUseCase: _registerUseCase,
//       verifyOTPUseCase: _verifyOTPUseCase,
//       resendOTPUseCase: _resendOTPUseCase,
//       authRepository: _repository,
//     );
//
//     // Load user từ storage TRƯỚC KHI restore session
//     await _authControllerInstance!.loadUserFromStorage();
//
//     // Kiểm tra xem có user trong storage không
//     if (_authControllerInstance!.currentUser != null) {
//       print('📱 Found user in storage: ${_authControllerInstance!.currentUser!.email}');
//
//       // Nếu có user, restore session từ cookies
//       WidgetsBinding.instance.addPostFrameCallback((_) async {
//         await restoreUserSession();
//       });
//     } else {
//       print('📱 No user found in storage');
//     }
//
//     _initialized = true;
//   }
//   // Trả về SINGLETON AuthController
//   static AuthController getAuthController() {
//     if (!_initialized) {
//       init(); // Chú ý: đây là sync, nhưng init() là async
//     }
//     return _authControllerInstance!;
//   }
//
//   // Thêm method để restore user từ cookies
//   static Future<void> restoreUserSession() async {
//     try {
//       print('🔄 AuthDI: Đang khôi phục session từ cookies...');
//       await _authControllerInstance?.restoreSession();
//       print('✅ AuthDI: Session restored successfully');
//     } catch (e) {
//       print('❌ AuthDI: Không thể restore session: $e');
//     }
//   }
//
//   // Getter cho Dio
//   static Dio get dio {
//     if (!_initialized) {
//       init();
//     }
//     return _dio;
//   }
//
//   // Getter cho CookieJar
//   static CookieJar get cookieJar {
//     return _cookieJar;
//   }
//
//   // Reset tất cả
//   static void reset() {
//     _initialized = false;
//     _cookieJar.deleteAll(); // Xóa cookies khi reset
//   }
// }
// auth_dependency_injection.dart
import 'package:dio/dio.dart';
import 'package:cookie_jar/cookie_jar.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:laundry_app/src/core/config/app_config.dart';
import 'package:laundry_app/src/features/auth/data/datasources/auth_remote_data_source.dart';
import 'package:laundry_app/src/features/auth/data/repositories/auth_repository_impl.dart';
import 'package:laundry_app/src/features/auth/domain/repositories/auth_repository.dart';
import 'package:laundry_app/src/features/auth/domain/usecases/login_usecase.dart';
import 'package:laundry_app/src/features/auth/domain/usecases/register_usecase.dart';
import 'package:laundry_app/src/features/auth/domain/usecases/verify_otp_usecase.dart';
import 'package:laundry_app/src/presentation/controllers/auth_controller.dart';

class AuthDI {
  // CookieJar để lưu cookies
  static final CookieJar _cookieJar = CookieJar();

  // ✅ INTERCEPTOR ĐỂ TỰ ĐỘNG THÊM TOKEN VÀO HEADER
  static final Interceptor _tokenInterceptor = InterceptorsWrapper(
    onRequest: (options, handler) async {
      // Lấy token từ storage
      final storage = GetStorage();
      final userJson = storage.read<Map<String, dynamic>>('current_user');
      final token = userJson?['token'];

      if (token != null && token is String && token.isNotEmpty) {
        // ✅ Thêm token vào cookie header
        options.headers['cookie'] = 'token=$token';
        print('🔑 Token added to request: ${options.path}');
      } else {
        print('⚠️ No token found for request: ${options.path}');
      }

      return handler.next(options);
    },
    onResponse: (response, handler) {
      if (AppConfig.enableLogging) {
        print('[Auth API] Response[${response.statusCode}]: ${response.requestOptions.path}');
      }
      return handler.next(response);
    },
    onError: (error, handler) {
      if (AppConfig.enableLogging) {
        print('[Auth API] Error[${error.response?.statusCode}]: ${error.requestOptions.path}');
      }
      return handler.next(error);
    },
  );

  // Dio Instance với CookieManager VÀ TokenInterceptor
  static final Dio _dio = Dio(
    BaseOptions(
      baseUrl: AppConfig.baseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    ),
  )..interceptors.addAll([
    CookieManager(_cookieJar), // Cookie manager
    _tokenInterceptor,          // ✅ Token interceptor
    LogInterceptor(
      requestBody: true,
      responseBody: true,
      requestHeader: true,
      responseHeader: true,
      logPrint: (obj) => print('[Auth API] $obj'),
    ),
  ]);

  // SINGLETON AuthController instance
  static AuthController? _authControllerInstance;

  // Initialize flag
  static bool _initialized = false;

  // Initialize tất cả dependencies và khôi phục session
  static Future<void> init({String? customBaseUrl}) async {
    if (_initialized) return;

    // Khởi tạo GetStorage
    await GetStorage.init();

    // Nếu có custom base URL, set environment
    if (customBaseUrl != null) {
      EnvironmentConfig.setEnvironment(EnvironmentConfig.development);
    }

    // Khởi tạo Data Source
    final _remoteDataSource = AuthRemoteDataSourceImpl(dio: _dio);

    // Khởi tạo Repository
    final _repository = AuthRepositoryImpl(remoteDataSource: _remoteDataSource);

    // Khởi tạo Use Cases
    final _loginUseCase = LoginUseCase(_repository);
    final _registerUseCase = RegisterUseCase(_repository);
    final _verifyOTPUseCase = VerifyOTPUseCase(_repository);
    final _resendOTPUseCase = ResendOTPUseCase(_repository);

    // Khởi tạo AuthController SINGLETON
    _authControllerInstance = AuthController(
      loginUseCase: _loginUseCase,
      registerUseCase: _registerUseCase,
      verifyOTPUseCase: _verifyOTPUseCase,
      resendOTPUseCase: _resendOTPUseCase,
      authRepository: _repository,
    );

    // Load user từ storage
    await _authControllerInstance!.loadUserFromStorage();

    // Kiểm tra xem có user trong storage không
    if (_authControllerInstance!.currentUser != null) {
      print('📱 Found user in storage: ${_authControllerInstance!.currentUser!.email}');

      // ✅ Kiểm tra token có tồn tại không
      if (_authControllerInstance!.hasValidToken) {
        print('🔑 Valid token found - AUTO LOGIN SUCCESS');
        // ✅ Đã có token → Tự động đăng nhập thành công
        // Không cần gọi API, chỉ cần token trong header là đủ
      } else {
        print('⚠️ User found but no valid token - need to re-login');
        // Clear user nếu không có token
        await _authControllerInstance!.logout();
      }
    } else {
      print('📱 No user found in storage - need to login');
    }

    _initialized = true;
  }

  // Trả về SINGLETON AuthController
  static AuthController getAuthController() {
    if (!_initialized) {
      throw Exception('AuthDI not initialized. Call AuthDI.init() first.');
    }
    return _authControllerInstance!;
  }

  // Thêm method để restore user từ cookies
  static Future<void> restoreUserSession() async {
    try {
      print('🔄 AuthDI: Đang khôi phục session từ cookies...');

      // Kiểm tra token trước khi gọi API
      if (!_authControllerInstance!.hasValidToken) {
        print('⚠️ No valid token, skipping session restore');
        return;
      }

      await _authControllerInstance?.restoreSession();
      print('✅ AuthDI: Session restored successfully');
    } catch (e) {
      print('❌ AuthDI: Không thể restore session: $e');
      // Clear user data nếu restore thất bại
      await _authControllerInstance?.logout();
    }
  }

  // Getter cho Dio
  static Dio get dio {
    if (!_initialized) {
      throw Exception('AuthDI not initialized. Call AuthDI.init() first.');
    }
    return _dio;
  }

  // Getter cho CookieJar
  static CookieJar get cookieJar {
    return _cookieJar;
  }

  // Reset tất cả
  static void reset() {
    _initialized = false;
    _authControllerInstance = null;
    _cookieJar.deleteAll(); // Xóa cookies khi reset
  }
}